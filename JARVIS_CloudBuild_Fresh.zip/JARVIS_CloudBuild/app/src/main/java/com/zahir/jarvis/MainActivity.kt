package com.zahir.jarvis
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.webkit.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale
class MainActivity : Activity(), TextToSpeech.OnInitListener {
 private lateinit var web: WebView; private var tts: TextToSpeech?=null
 private val speechRequest=701; private val audioPermission=702
 override fun onCreate(savedInstanceState: Bundle?){super.onCreate(savedInstanceState);tts=TextToSpeech(this,this);web=WebView(this);web.settings.javaScriptEnabled=true;web.settings.domStorageEnabled=true;web.webChromeClient=WebChromeClient();web.webViewClient=WebViewClient();web.addJavascriptInterface(Bridge(),"Android");setContentView(web);web.loadUrl("file:///android_asset/index.html")}
 inner class Bridge { @JavascriptInterface fun speak(message:String){runOnUiThread{tts?.speak(message,TextToSpeech.QUEUE_FLUSH,null,"reply")}}; @JavascriptInterface fun startListening(){runOnUiThread{if(ContextCompat.checkSelfPermission(this@MainActivity,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)ActivityCompat.requestPermissions(this@MainActivity,arrayOf(Manifest.permission.RECORD_AUDIO),audioPermission) else launchSpeech()}} }
 private fun launchSpeech(){val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.getDefault())};try{startActivityForResult(i,speechRequest)}catch(_:Exception){}}
 override fun onRequestPermissionsResult(r:Int,p:Array<out String>,g:IntArray){super.onRequestPermissionsResult(r,p,g);if(r==audioPermission&&g.isNotEmpty()&&g[0]==PackageManager.PERMISSION_GRANTED)launchSpeech()}
 @Deprecated("Deprecated") override fun onActivityResult(r:Int,result:Int,data:Intent?){super.onActivityResult(r,result,data);if(r==speechRequest&&result==RESULT_OK){val spoken=data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?:return;web.evaluateJavascript("window.jarvisVoiceResult(${org.json.JSONObject.quote(spoken)});",null)}}
 override fun onInit(status:Int){if(status==TextToSpeech.SUCCESS)tts?.language=Locale.getDefault()}
 override fun onDestroy(){tts?.shutdown();web.destroy();super.onDestroy()}
}
