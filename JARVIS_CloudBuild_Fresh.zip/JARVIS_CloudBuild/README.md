# JARVIS Android app

Android Studio starter project with a futuristic interface, Android speech recognition, spoken replies, local notes, date/time and web search shortcuts.

## Build APK
GitHub Actions builds a debug APK on pushes to `main` or when manually started from Actions. Download the `JARVIS-debug-apk` artifact from a successful workflow run and extract `app-debug.apk`.

This is a starter assistant, not a fully connected generative AI. Full AI responses require a secure backend and an AI service connection. Never put private API keys in app source code.
